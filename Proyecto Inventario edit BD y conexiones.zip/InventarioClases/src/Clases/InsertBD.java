
package Clases;

import bdpostgresql.database_inventario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class InsertBD {

    public InsertBD() {
    
    }

    public String IngresarArticulos(Producto dato){
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        String mensaje="";
        
        try{
            //Connection conex = DriverManager.getConnection("jdbc:postgresql://localhost:5432/inventarios", "postgres", "123");
            Statement con = conex.createStatement();
            String orden = "INSERT INTO public.producto(\n" +
                           "nombre, id_producto, categoria, precio, cantidad)\n" +
                           "VALUES ("+dato.getNombreProducto()+","+dato.idProducto +","+dato.getCategoria()+","+dato.getPrecio()+","+dato.getCantidad()+");";
            con.executeUpdate(orden);
            mensaje="Articulo Guardado con Exito";
            
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null, e);
        }
        
        return mensaje;
    }

    
    
    
}
/*INSERT INTO public.producto(
	nombre, id_producto, categoria, precio, cantidad)
	VALUES (?, ?, ?, ?, ?);*/