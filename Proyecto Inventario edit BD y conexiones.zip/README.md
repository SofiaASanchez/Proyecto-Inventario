# Proyecto-Inventario

Lenguaje - Java

Al concluir este proyecto tendremos un sistema de inventario con sus funciones mas basicas.
En el archivo con extension pdf se pueden apreciar con mayor detalle los casos de uso de este sistema.

Integrantes:
Luis Fernando Martinez  - 20101005473
Byron Francisco Canaca  - 20141010493
Fredy Ariel Montoya     - 20151003211
Jared Misael Castro     - 20151020512
