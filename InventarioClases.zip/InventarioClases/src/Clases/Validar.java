
package Clases;

import static com.sun.javafx.tk.Toolkit.getToolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;


public class Validar {


    
    
    /*public boolean validarNum(String cadena){
        int num;
        try{
            num = Integer.parseInt(cadena);
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    public  void validarLetras(JTextField mensaje){
        mensaje.addKeyListener(new KeyAdapter() {
        public void KeyTyped(KeyEvent e){
            char c = e.getKeyChar();
            if(Character.isDigit(c)){
                
                e.consume(); 
            }
        }          
        });
    }
    
    public  void validarNumeros(JTextField mensaje){
        mensaje.addKeyListener(new KeyAdapter() {
        public void KeyTyped(KeyEvent e){
            char c = e.getKeyChar();
            if(!Character.isDigit(c)){
                
                e.consume(); 
            }
        }          
        });
    }
    
    public  void limitarCaracteres(JTextField mensaje, int campo){
        mensaje.addKeyListener(new KeyAdapter() {
        public void KeyTyped(KeyEvent e){
            char c = e.getKeyChar();
            int tamano = mensaje.getText().length();
            
            if(tamano>=campo){
                
                e.consume(); 
            }
        }          
        });
    }*/
}