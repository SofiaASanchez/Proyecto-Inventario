
package Clases;

import bdpostgresql.database_inventario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class InsertBD {

    public InsertBD() {
    
    }

    
    public String ingresarArticulos(Producto dato){
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        String mensaje="";
        
        try{
            //Connection conex = DriverManager.getConnection("jdbc:postgresql://localhost:5432/inventarios", "postgres", "123");
            Statement con = conex.createStatement();
            String orden = "INSERT INTO public.producto(\n" +
                           " nombre, id_producto, categoria, precio, cantidad, proveedor)" +
                           "VALUES ("+dato.getNombreProducto()+","+dato.idProducto +","+dato.getCategoria()+","+dato.getPrecio()+","+dato.getCantidad()+","+dato.getProveedor()+");";
            con.executeUpdate(orden);
            mensaje="Articulo Guardado con Exito";
            
            
        }catch(Exception e){
            
            //JOptionPane.showMessageDialog(null, e);
            mensaje="Algo Salio mal Verifica tus datos";
        }
        
        return mensaje;
    }

    public String ingresarUsuario(Usuario usuario){
        String mensaje="";
        Usuario dato= usuario;
        
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        try{
            
            Statement con = conex.createStatement();
            String orden="INSERT INTO usuarios(\n" +
                         "id, nombre, apellido, direccion, telefono, fecha_naci, contra, tipopermiso)\n" +
                         "VALUES ("+dato.getId_persona()+", "+dato.getNombre() +", "+dato.getApellido()+", \n"+
                          dato.getDireccion()+", "+dato.getTelefono()+", "+dato.getFecha_nacimiento()+",\n"+
                          dato.getContrasena()+", "+dato.getTipo_usuario()+" );";
            
            con.executeUpdate(orden);
            mensaje = "Guardado Con EXITO";
          
        }catch(Exception e){
            
            mensaje = e.getMessage();
        }
        
        return mensaje;
    }
    public String ingresarFactura(Factura factura){
        String mensaje="";
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        try{
            
            Statement con = conex.createStatement();
            String orden="INSERT INTO public.factura(\n" +
                          "fecha, cliente, articulos, total)\n" +
                          "VALUES ('"+factura.getFecha()+"','"+factura.getNombrecliente()+"','"+factura.getArticulos()+"' ,'"+factura.getTotal()+"' );";
            
            con.executeUpdate(orden);
            JOptionPane.showMessageDialog(null, "Guardado Con EXITO");
            
            orden = "SELECT numerofactura \n" +
                           "FROM public.factura WHERE cliente='"+factura.getNombrecliente()+"';";
            
            ResultSet rs = con.executeQuery(orden);
            rs.next();
            mensaje =rs.getString("numerofactura");
          
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Guardado Con EXITO");
        }
        
        return mensaje;
    }
    
    public String ingresarProveedor(Proveedor dato){
        String mensaje="";
        
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        
        try{
            //Connection conex = DriverManager.getConnection("jdbc:postgresql://localhost:5432/inventarios", "postgres", "123");
            Statement con = conex.createStatement();
            String orden = "INSERT INTO public.proveedor(\n" +
                           " id_proveedor, nombreproveedor, descripcion)" +
                           "VALUES ("+dato.getId_proveedor()+","+dato.getNombre() +","+dato.getDescripcion()+");";
            con.executeUpdate(orden);
            mensaje="Proveedor Guardado con Exito";
            
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null, e);
            mensaje="Algo Salio mal Verifica tus datos";
        }
        
        return mensaje;
       
    }
 
}
/*INSERT INTO public.producto(
	nombre, id_producto, categoria, precio, cantidad)
	VALUES (?, ?, ?, ?, ?);*/