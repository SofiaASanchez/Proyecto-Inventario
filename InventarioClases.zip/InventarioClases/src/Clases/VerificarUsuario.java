
package Clases;

import bdpostgresql.database_inventario;
import javax.swing.*;
import java.sql.*;

public class VerificarUsuario {

    String nombre;
    String contra;
    
    public VerificarUsuario() {
        
    }
    
    
    public VerificarUsuario(String nombre, String contra) {
        this.nombre=nombre;
        this.contra=contra;
    }

    public boolean tipoUsuario(String nombre, String contra){
    
    boolean tipo= false;
    
    database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        
        try{
           // Connection conex = DriverManager.getConnection("jdbc:postgresql://localhost:5432/inventarios", "postgres", "123");
            PreparedStatement datos = conex.prepareStatement("SELECT contra, nombre, tipopermiso FROM usuarios WHERE contra = ?");
            datos.setString(1,contra);
            
            ResultSet rs = datos.executeQuery();
            rs.next();
            
          if(rs.getString("nombre").equals(nombre)){
              
              if(rs.getString("tipopermiso").equals("1")){
                  tipo=true;
                  
              }
              
              return tipo;
          }else{
              return tipo;
          }
                
           
            
        }catch(Exception e){
            
            //JOptionPane.showMessageDialog(null, "Datos no Validos");
        }
    
    return tipo;
}
 
    public boolean validarUsuario(String nom, String cont){
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        boolean dec=false;
        
        try{
           // Connection conex = DriverManager.getConnection("jdbc:postgresql://localhost:5432/inventarios", "postgres", "123");
            PreparedStatement datos = conex.prepareStatement("SELECT contra, nombre FROM usuarios WHERE contra = ?");
            datos.setString(1,cont);
            
            ResultSet rs = datos.executeQuery();
            rs.next();
            
          if(rs.getString("nombre").equals(nom)){
              dec=true;
              return dec;
          }else{
              return dec;
          }
                
           
            
        }catch(Exception e){
            
            //JOptionPane.showMessageDialog(null, "Datos no Validos");
        }
        
        return dec;
        
    }
            
}
