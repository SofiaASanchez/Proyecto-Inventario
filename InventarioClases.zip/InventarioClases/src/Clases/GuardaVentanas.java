
package Clases;

import Interfaz.UI_Menu;


public class GuardaVentanas {

    String nombre;
    public void menu(String nombre){

        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }


    
    
}
