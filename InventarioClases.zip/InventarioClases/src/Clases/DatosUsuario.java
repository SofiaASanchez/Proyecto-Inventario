
package Clases;


public class DatosUsuario {
    static String nombre="";
    static String permiso="";
    static String id="";
    public DatosUsuario() {
    
    }

    
    
    public static void datos(String nombre, String permiso) {
    DatosUsuario.nombre = nombre;
    DatosUsuario.permiso = permiso;
    }
    
    public static void id(String id){
        DatosUsuario.id = id;
    }

    public static String getId() {
        return id;
    }

    public static String getNombre() {
        return nombre;
    }

    public static String getPermiso() {
        return permiso;
    }


    
    
}
