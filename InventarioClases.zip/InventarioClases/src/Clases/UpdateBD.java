
package Clases;

import Interfaz.Gestion_Usuarios.UI_UsuarioMod;
import bdpostgresql.database_inventario;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;



public class UpdateBD {

    public UpdateBD() {
    }
    
    
    public String updateUduario(String id, Usuario datos){
        String mensaje="";
        database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        try {
            Statement st = conex.createStatement();
            String orden = "UPDATE usuarios\n" +
"	SET id="+datos.getId_persona()+", nombre="+datos.getNombre()+", apellido ="+datos.getApellido()+", direccion= "+datos.getDireccion()+", telefono="+datos.getTelefono()+", fecha_naci="+datos.getFecha_nacimiento()+",contra="+datos.getContrasena()+", tipopermiso="+datos.getTipo_usuario()
                    + "	WHERE id="+id+";";
            //System.out.print(orden);
                    
                    
                    
            
            mensaje="Actualizado correctamente";
            ResultSet rs = st.executeQuery(orden);
     
        } catch (SQLException e) {
            mensaje="Actualizado correctamente";
            //System.out.print(e);
            //JOptionPane.showMessageDialog(null, e);
        }
        
        return mensaje;
    }
    
    public String updateProducto(Producto datos){
        
        String mensaje ="";
         database_inventario enlace = new database_inventario();
        Connection conex = enlace.conexion();
        
        try {
            Statement st = conex.createStatement();
            String orden = "UPDATE public.producto\n" +
"	SET nombre="+datos.getNombreProducto()+", id_producto="+datos.getIdProducto()+", categoria="+datos.getCategoria()+", precio="+datos.getPrecio()+", cantidad="+datos.getCantidad()+", proveedor="+datos.getProveedor()+"\n" +
"	WHERE id_producto = '"+DatosUsuario.getIdProducto()+"';";
            //System.out.print(orden);
                    
                    
                    
            
            mensaje="Actualizado correctamente";
            ResultSet rs = st.executeQuery(orden);
     
        } catch (SQLException e) {
            mensaje="Actualizado correctamente";
            //System.out.print(e);
            //JOptionPane.showMessageDialog(null, e);
        }
        
        return mensaje;
    }
}
